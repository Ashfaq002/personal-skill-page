# SCRAPPIN GTHE AMAZON TOA CCESS THE DATA OF THE SMART PHONE PRICE LISTSINGS
import requests
from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.common.by import By
import time

# GAINI9NG THE ACCESS TO THE AMAZON WEPAGAE

WEBPAGE_URL = "https://www.amazon.in/gp/bestsellers/videogames/20904621031/ref=zg_bs_nav_videogames_1"

# GIVING THE WEBPAGE HEADERS TO ACCESS THE CORRECT WEBPAGE
USER_AGENT = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 "
              "Safari/537.36")
ACCEPT_LANGUAGE = "en-US,en;q=0.9"

HEADERS = {
    "User-Agent": USER_AGENT,
    "Accept-Language": ACCEPT_LANGUAGE
}
response = requests.get(WEBPAGE_URL, headers=HEADERS)
print(response.raise_for_status())
page = response.text

# USING BEAUTIFUL SOUP TO SCRRAP THE WEBAPGE
soup = BeautifulSoup(page, "html.parser")
# print(soup.prettify())
page_html = soup.prettify()

#with open("amazon_ps5_game_data.html","w", encoding="utf-8") as file:
    #file.write(page_html)

# USIN GBEAUTIFUL SOUP TO SCRAP THE WEBPAGE AND GET THE ELEMENTS FROM THE HTML TAG
ALL_PRODUCT_LINK_ELEMENT =  soup.select(".zg-grid-general-faceout a")
all_links = []
for link in ALL_PRODUCT_LINK_ELEMENT:
    href = link["href"]
    if 'https' not in href:
        all_links.append(f"https://amazon.in{href}")

    else:
        all_links.append(href)

print(f"{all_links}\n")

# USING FOR LOOP TO LOOP THROUGH EACH LINK FROM THE ALL_LINKS LIST
# for link in all_links:
    # print(link)
# with open("all_links.txt", "w", encoding="utf-8") as file:
    # for link in all_links:
        # file.write(link)

# SCRAPPING THE PRODUCT NAMES


ALL_PRODUCT_NAMES_ELEMENT = soup.select("._cDEzb_p13n-sc-css-line-clamp-1_1Fn1y")
all_names = [name.get_text() for name in ALL_PRODUCT_NAMES_ELEMENT]
print(all_names)

# with open("all_names.txt", "w", encoding="utf-8") as file:
    # for name in all_names:
        # file.write(f"{name}\n")

# NOW SCRAPPING THE ALL THE PRODUCT PRICES FORM THE PRICE TAG
# ALL_PRICE_ELEMENTS = soup.select("._cDEzb_p13n-sc-price-animation-wrapper_3PzN2")
ALL_PRICE_ELEMENTS = soup.select("._cDEzb_p13n-sc-price-animation-wrapper_3PzN2 span")
all_prices = [price.get_text() for price in ALL_PRICE_ELEMENTS]
print(all_prices)

# AUTOMATION
GOOGLE_FORM_URL = "https://docs.google.com/forms/d/e/1FAIpQLSfTnSVmG3PmPRKbm6RqjowgTV9DtThdZLgBz2gMchP8YSt6mA/viewform"
chrome_options = webdriver.ChromeOptions()
chrome_options.add_experimental_option("detach", True)

bot = webdriver.Chrome(options=chrome_options)

for n in range(len(all_links)):
    bot.get(GOOGLE_FORM_URL)
    time.sleep(3)

    name = bot.find_element(By.XPATH, "//*[@id='mG61Hd']/div[2]/div/div[2]/div[1]/div/div/div[2]/div/div[1]/div/div[1]/input")
    price = bot.find_element(By.XPATH, '//*[@id="mG61Hd"]/div[2]/div/div[2]/div[2]/div/div/div[2]/div/div[1]/div/div[1]/input')
    link = bot.find_element(By.XPATH, '//*[@id="mG61Hd"]/div[2]/div/div[2]/div[3]/div/div/div[2]/div/div[1]/div/div[1]/input')

    submit_button = bot.find_element(By.XPATH, '//*[@id="mG61Hd"]/div[2]/div/div[3]/div[1]/div[1]/div/span/span')

    name.send_keys(all_names[n])
    time.sleep(2)
    price.send_keys(all_prices[n])
    time.sleep(2)
    link.send_keys(all_links[n])
    time.sleep(2)
    submit_button.click()



