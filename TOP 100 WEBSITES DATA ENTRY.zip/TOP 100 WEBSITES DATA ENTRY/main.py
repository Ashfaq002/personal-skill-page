# SCRAPPING AN WEBAPGE TO GET THE DATA FROM THW EBPAGE AND CREATE A SPREADSHEET OF THE WEBSITES DATA ENTRY
import requests
from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.common.by import By

# GETTING THE ACCESS TO THE WEBAPAGE TO GET THE DATA FROM THE HTML
WEBPAGE_PAGE_URL = "https://www.labnol.org/internet/101-useful-websites/18078/"

# GIVING THE WEBPAGE HEADERS TO ACCESS THE CORRECT WEBPAGE
USER_AGENT = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 "
              "Safari/537.36")
ACCEPT_LANGUAGE = "en-US,en;q=0.9"

HEADERS = {
    "User-Agent": USER_AGENT,
    "Accept-Language": ACCEPT_LANGUAGE
}
response = requests.get(WEBPAGE_PAGE_URL, headers=HEADERS)
response.raise_for_status()
WEBPAGE_HTML_FORMAT = response.text

# USING BEAUTIGUL SOUP TO SCRAP THROUGH THE ELEEMNTS OF THE WEBAPGE
soup = BeautifulSoup(WEBPAGE_HTML_FORMAT, "html.parser")
# print(soup.prettify())
# saving the html format of the webpage as an html file
prettify = soup.prettify()

# with open("TOP 100 WEBSITES PAGE.html", "w") as file:
    # file.write(prettify)
# SCRAPPIN GTHE ELEMENTS OF THE WEBPAGE FROM THE HTML TAG ELEMEMTS
ALL_WEBPAGE_NAME_ELEMENT = soup.select("div .prose prose-slate max-w-full #h2 ol li a")
#tag = ALL_WEBPAGE_NAME_ELEMENT.select("ol li")
# creating an list comprehension
all_names = [name.getText() for name in ALL_WEBPAGE_NAME_ELEMENT]
print(all_names)


