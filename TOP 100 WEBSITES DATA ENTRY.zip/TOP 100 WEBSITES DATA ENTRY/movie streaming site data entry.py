import requests
from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.common.by import By
import time


WEBPAGE_URL = "https://vpnoverview.com/unblocking/streaming/free-movie-streaming-sites/"

# GIVING THE WEBPAGE HEADERS TO ACCESS THE CORRECT WEBPAGE
USER_AGENT = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 "
           "Safari/537.36")
ACCEPT_LANGUAGE = "en-US,en;q=0.9"

HEADERS = {
    "User-Agent": USER_AGENT,
    "Accept-Language": ACCEPT_LANGUAGE
}
response = requests.get(WEBPAGE_URL, headers=HEADERS)
response.raise_for_status()
ht_rep = response.text

soup = BeautifulSoup(ht_rep, "html.parser")
# print(soup.prettify())

ALL_SITES_LINK_ELEMENT = soup.select(".content-top li a")
all_links = []
for link in ALL_SITES_LINK_ELEMENT:
    href = link["href"]
    if 'https' not in href:
        all_links.append(f"https://vpnoverview.com/unblocking/streaming/free-movie-streaming-sites/{href}")
    else:
        all_links.append(href)

print(all_links)


ALL_SITES_NAME_ELEMENT = soup.select(".content-top li a")
all_names = [name.get_text() for name in ALL_SITES_NAME_ELEMENT]
print(all_names)

ALL_DISCRIB_ELEMENT = soup.select(".content-top li")
all_discribtions = [discribtion.get_text().split(':')[-1] for discribtion in ALL_DISCRIB_ELEMENT]
print(all_discribtions)

chrome_options = webdriver.ChromeOptions()
chrome_options.add_experimental_option("detach", True)

GOOGLE_FORM_URL = "https://docs.google.com/forms/d/e/1FAIpQLSdJMWgURlRCwXMkWX6DUsQ_sjImta4zZM7AxEFaIitVy8VAkQ/viewform"
bot = webdriver.Chrome(options=chrome_options)

for n in range(len(all_links)):
    bot.get(GOOGLE_FORM_URL)

    time.sleep(3)
    name = bot.find_element(By.XPATH, '//*[@id="mG61Hd"]/div[2]/div/div[2]/div[1]/div/div/div[2]/div/div[1]/div/div[1]/input')
    describ = bot.find_element(By.XPATH, '//*[@id="mG61Hd"]/div[2]/div/div[2]/div[2]/div/div/div[2]/div/div[1]/div/div[1]/input')
    link = bot.find_element(By.XPATH, '//*[@id="mG61Hd"]/div[2]/div/div[2]/div[3]/div/div/div[2]/div/div[1]/div/div[1]/input')
    submit_button = bot.find_element(By.XPATH, '//*[@id="mG61Hd"]/div[2]/div/div[3]/div[1]/div[1]/div/span/span')

    name.send_keys(all_names[n])
    describ.send_keys(all_discribtions[n])
    link.send_keys(all_links[n])
    submit_button.click()
