names = ["TurboSlayer",
         "CrypticHatter",
         "CrashTV",

         "Blue Defender",

         "Toxic Headshot",

         "IronMerc",

         "SteelTitan",

         "StealthedDefender",

         "Blaze Assault",

         "Venom Fate",

         "DarkCarnage",

         "FatalDestiny",

         "UltimateBeast",

         "Masked Titan",

         "Frozen Gunner"]
