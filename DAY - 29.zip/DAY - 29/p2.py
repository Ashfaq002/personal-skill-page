# password manager
# importing message box class to show pop up messages on the screen
from tkinter import *
from tkinter import messagebox
import random
import pyperclip
from usernames import names
import json

# setting the text font custom
FONT = ("Times New Roman", 15, "bold")


# creating random username

def generate_username():
    user_name = random.choice(names)
    username_entry_panel.insert(0, user_name)
    pyperclip.copy(user_name)


# creating random password generator
def generate_password():
    letters = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u',
               'v',
               'w', 'x', 'y', 'z', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q',
               'R',
               'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z']
    numbers = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']
    symbols = ['!', '#', '$', '%', '&', '(', ')', '*', '+']

    # using list comprehension
    password_letters = [random.choice(letters) for _ in range(random.randint(8, 10))]
    password_symbols = [random.choice(symbols) for _ in range(random.randint(2, 4))]
    password_numbers = [random.choice(numbers) for _ in range(random.randint(2, 4))]

    password_list = password_letters + password_symbols + password_numbers
    # shuffling the password list
    random.shuffle(password_list)
    password = "".join(password_list)
    # isnerting the random generated paswrd into the panel
    password_entry_panel.insert(0, password)
    # copying the password into the clipboard
    pyperclip.copy(password)


# creating an function to save the datas
# when add button is clicked the details will be saved into the file
def save():
    website = website_entry_panel.get().upper()
    username = username_entry_panel.get()
    email = email_entry_panel.get()
    password = password_entry_panel.get()
    new_data = {
        website: {
            "username": username,
            "email": email,
            "password": password
        }
    }

    # show an pop up message with error if not enetred any details
    if len(website) == 0 or len(username) == 0 or len(email) == 0 or len(password) == 0:
        messagebox.showinfo(title="ERROR", message="Please fill all the entries")

    else:
        # shwoing an pop up message when the add button is clicked
        is_ok = messagebox.askokcancel(title=website, message=f"Please check the below details are correct:\n"
                                                              f"username:{username}\n email:{email}\n Password:{password}\n"
                                                              f"Are you sure to save?")
        if is_ok:
            # adding the error exceptions
            try:
                # trying loading the json file and assuming it may cause error
                with open("account_data.json", "r") as data_file:
                    # data_file.write(f"{website}||{username}||{email}||{password}\n")
                    # json.dump(new_data, data_file, indent=4)
                    # reading and updating the json data file
                    data = json.load(data_file)
            # if the file is not found. it should create that using FILE NOT FOUND ERROR EXCEPT FORMAT
            except FileNotFoundError:
                json.dump(new_data, data_file, indent=4)
            else:
                # updating the existing json data with new data file
                data.update(new_data)

                with open("account_data.json", "w") as data_file:

                    # using json format to store the file
                    # to create a new JSON file
                    json.dump(data, data_file, indent=4)
            # after all the error exceptions passes it should go to the final exception format
            finally:
                # after storing the datas into the file. the previous datas on the entry panel should get deletd
                # delete()-> delets the text
                website_entry_panel.delete(0, END)
                username_entry_panel.delete(0, END)
                email_entry_panel.delete(0, END)
                password_entry_panel.delete(0, END)


# ----------------UI SETUP---------------#
#  creating the window tab
window_tab = Tk()
window_tab.title("Password Manager")
# setting the height and width of the window tab
window_tab.config(padx=50, pady=50)

# creating the canavas class here and implementing the methods of it
canvas = Canvas(width=200, height=200)
# adding the image into the canvas
img = PhotoImage(file="logo.png")
# setting the height and width of the image inside the canvas
canvas.create_image(100, 100, image=img)
# placing the canvas inside the window tab
canvas.grid(column=1, row=0)

# creating website entry panel 
website_entry_panel = Entry(width=35)
website_entry_panel.grid(column=1, row=2)
# focuisng the mouse cursor into the website entry panel
website_entry_panel.focus()

# creating the website label
website_label = Label(text="Website:", font=FONT)
website_label.grid(column=0, row=2)

# creating user name entry panel
username_entry_panel = Entry(width=35)
username_entry_panel.grid(column=1, row=3)

# creating username label
username_label = Label(text="Username:", font=FONT)
username_label.grid(column=0, row=3)

# creating user name generate button
username_generate = Button(text="Generate username", font=("Times New Roman", 11, "bold"), highlightthickness=0,
                           command=generate_username)
username_generate.grid(column=2, row=3)
# creating email entry panel
email_entry_panel = Entry(width=34)
email_entry_panel.grid(column=1, row=4)
# creating email label
email_label = Label(text="Email:", font=FONT)
email_label.grid(column=0, row=4)

# creating password entry panel
password_entry_panel = Entry(width=26)
password_entry_panel.grid(column=1, row=5)
# passowrd label

password_label = Label(text="Password: ", font=FONT)
password_label.grid(column=0, row=5)

# creating generate password button
generate_password_button = Button(text="Generate Password", font=("Times New Roman", 11, "bold"), highlightthickness=0,
                                  command=generate_password)
generate_password_button.grid(column=2, row=5)

# creating add button
add_button = Button(text="Add", font=("Times New Roman", 12, "bold"), highlightthickness=0, width=20, command=save)
add_button.grid(column=1, row=6)


# creating search button
# adding up a event listener for the search button when it is clicked
def find_password():
    # getting hold of the website entry panel texts
    # if there is no website found in the json then it should show an error info messgae
    website = website_entry_panel.get().upper()
    try:
        with open("account_data.json") as data_file:
            data = json.load(data_file)
    except FileNotFoundError:
        messagebox.showinfo(title="ERROR", message="THE SPECIFIED FILE DOES NOT EXIST!")
    # if that particular website is in the json file. then get that website's email, password, and username
    else:
        if website in data:
            username = data[website]["username"]
            email = data[website]["email"]
            password = data[website]["password"]
            messagebox.showinfo(title=website, message=f"username:{username}\n "
                                                       f"email:{email}\n"
                                                       f"password:{password}")
        elif len(website) == 0:
            messagebox.showinfo(title="ERROR", message="Please fill the website name")
            # showing an error message info if there is no website like that
        else:
            messagebox.showinfo(title="ERROR", message=f"there is no info on that website{website},"
                                                       f"the website does not exist")


website_search_button = Button(text="Search", font=("Times New Roman", 9, "bold"), width=10, command=find_password)
website_search_button.grid(column=2, row=2)
window_tab.mainloop()
